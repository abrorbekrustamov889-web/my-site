# LEXI — Smart Vocabulary Learning Platform

Dark premium Next.js starter with PostgreSQL persistence, Prisma, name-only registration, recovery-code login, vocabulary, learning flashcards, tests, XP, leaderboard, and admin role foundation.

## Requirements
- Node.js 20.9+
- PostgreSQL 14+

## Setup
1. Copy `.env.example` to `.env` and set `DATABASE_URL` and a random `SESSION_SECRET` (32+ chars).
2. Install dependencies: `npm install`
3. Generate Prisma client and create tables: `npx prisma generate && npx prisma db push`
4. Add sample vocabulary: `npm run db:seed`
5. Start: `npm run dev`
6. Open http://localhost:3000

## Admin
Register your account first. Run `npx prisma studio`, find your user and set `role` to `ADMIN`. Admin registration is not public.

## Important security note
This MVP uses a random recovery code as the only login credential because the product requirement excludes email/password. The code is shown once; losing it means the account cannot be recovered. For production, add rate limiting, audit logging, CSRF review, session records with revocation, encrypted backups, and a verified recovery process. The starter uses an HMAC-signed HTTP-only session cookie. Add server-side session records/revocation and rate limiting before public launch.

## Current scope
Vocabulary, progress, XP, tests, leaderboard, and profile data persist in PostgreSQL. AI assistant and real-time multiplayer are interface placeholders pending provider credentials and WebSocket infrastructure. Daily streak automation, spaced-repetition scheduling, achievements, and full admin CRUD are planned next milestones.
