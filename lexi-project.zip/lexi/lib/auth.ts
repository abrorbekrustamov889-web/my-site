import { cookies } from 'next/headers';
import { createHash, createHmac, randomInt, timingSafeEqual } from 'crypto';
import { db } from './db';
const COOKIE = 'lexi_session';
const secret = () => process.env.SESSION_SECRET ?? 'dev-only-change-me';
export function hash(value: string) { return createHash('sha256').update(value).digest('hex'); }
const sign = (id:string) => createHmac('sha256',secret()).update(id).digest('hex');
export function createRecoveryCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let raw=''; for(let i=0;i<16;i++) raw += chars[randomInt(chars.length)];
  return `${raw.slice(0,4)}-${raw.slice(4,8)}-${raw.slice(8,12)}-${raw.slice(12)}`;
}
export async function setSession(userId: string) {
  const jar = await cookies();
  jar.set(COOKIE, `${userId}.${sign(userId)}`, { httpOnly:true, secure:process.env.NODE_ENV === 'production', sameSite:'lax', path:'/', maxAge:60*60*24*30 });
}
export async function currentUser() {
  const jar = await cookies(); const raw=jar.get(COOKIE)?.value; if(!raw) return null;
  const [id,signature,...extra]=raw.split('.'); if(!id||!signature||extra.length) return null;
  const expected=sign(id); const a=Buffer.from(signature); const b=Buffer.from(expected);
  if(a.length!==b.length || !timingSafeEqual(a,b)) return null;
  return db.user.findUnique({ where:{ id }, include:{ words:{ include:{ word:true } }, testAttempts:{ orderBy:{ createdAt:'desc' }, take:5 } } });
}
export async function signOut() { const jar = await cookies(); jar.delete(COOKIE); }
