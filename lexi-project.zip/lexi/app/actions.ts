'use server';
import { redirect } from 'next/navigation';
import { cookies } from 'next/headers';
import { revalidatePath } from 'next/cache';
import { db } from '@/lib/db';
import { createRecoveryCode, currentUser, hash, setSession, signOut } from '@/lib/auth';
import { z } from 'zod';
const nameSchema = z.string().trim().min(2).max(40).regex(/^[\p{L}\s'-]+$/u);
export async function register(formData: FormData) {
  const firstName = nameSchema.parse(formData.get('firstName'));
  const lastName = nameSchema.parse(formData.get('lastName'));
  const recoveryCode = createRecoveryCode();
  const user = await db.user.create({ data:{ firstName, lastName, recoveryHash:hash(recoveryCode) } });
  await setSession(user.id);
  const jar = await cookies();
  jar.set('lexi_recovery_flash', recoveryCode, { httpOnly:true, secure:process.env.NODE_ENV === 'production', sameSite:'strict', path:'/welcome', maxAge:300 });
  redirect('/welcome');
}
export async function login(formData: FormData) {
  const code = String(formData.get('recoveryCode') ?? '').trim().toUpperCase();
  const user = await db.user.findUnique({ where:{ recoveryHash:hash(code) } });
  if (!user) redirect('/login?error=invalid');
  await setSession(user.id);
  redirect('/dashboard');
}
export async function logout() { await signOut(); redirect('/'); }
export async function addWord(formData: FormData) {
  const user = await currentUser(); if (!user) redirect('/login');
  const english = String(formData.get('english') ?? '').trim();
  const uzbek = String(formData.get('uzbek') ?? '').trim();
  if (!english || !uzbek) return;
  const word = await db.word.upsert({ where:{ english }, update:{ uzbek }, create:{ english, uzbek, level:String(formData.get('level') ?? 'A1'), example:String(formData.get('example') ?? '') || null } });
  await db.userWord.upsert({ where:{ userId_wordId:{ userId:user.id, wordId:word.id } }, update:{}, create:{ userId:user.id, wordId:word.id } });
  revalidatePath('/vocabulary'); revalidatePath('/dashboard');
}
export async function updateWordStatus(id: string, status: 'LEARNING'|'MASTERED') {
  const user = await currentUser(); if (!user) redirect('/login');
  const relation = await db.userWord.findFirst({ where:{ id, userId:user.id } }); if (!relation) return;
  const wasMastered = relation.status === 'MASTERED';
  await db.userWord.update({ where:{ id }, data:{ status, correctCount:{ increment:1 } } });
  if (status === 'MASTERED' && !wasMastered) await db.user.update({ where:{ id:user.id }, data:{ xp:{ increment:10 } } });
  revalidatePath('/vocabulary'); revalidatePath('/dashboard');
}
export async function toggleFavorite(id: string) {
  const user = await currentUser(); if (!user) redirect('/login');
  const row = await db.userWord.findFirst({ where:{ id, userId:user.id } }); if (!row) return;
  await db.userWord.update({ where:{ id }, data:{ favorite:!row.favorite } }); revalidatePath('/vocabulary');
}
export async function saveTest(score: number, total: number) {
  const user = await currentUser(); if (!user) redirect('/login');
  await db.testAttempt.create({ data:{ userId:user.id, score, total } });
  await db.user.update({ where:{ id:user.id }, data:{ xp:{ increment:score*5 } } });
  revalidatePath('/dashboard');
}
