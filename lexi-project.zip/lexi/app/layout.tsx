import type { Metadata } from 'next';import './globals.css';
export const metadata:Metadata={title:'LEXI — Smart Vocabulary Learning',description:'Learn words. Level up. Go further.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="uz"><body>{children}</body></html>}
